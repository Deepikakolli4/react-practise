import React from "react";
import ReactDOM from "react-dom";
const customStyle = {
  color: "blue",
  fontSize: "100px",
  border: "10px solid black",
};
customStyle.color = "black"; //updated colour
ReactDOM.render(
  <h1 style={customStyle}>Hello World!</h1>,
  document.getElementById("root")
);
