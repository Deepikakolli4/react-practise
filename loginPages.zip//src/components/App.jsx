import React, { useState } from "react";

function App() {
  const [name, setName] = useState("");
  const [isSubmit, setisSubmit] = useState(false);

  function handleChange(event) {
    setName(event.target.value);
  }

  return (
    <div className="container">
      {isSubmit ? (
        <>
          <h1>Welcome {name}</h1>
          <button
            onClick={() => {
              setisSubmit(false);
            }}
            type="submit"
          >
            Go Back
          </button>
        </>
      ) : (
        <div>
          <h1>Hello</h1>
          <form
            onSubmit={() => {
              setisSubmit(true);
            }}
          >
            <input
              onChange={handleChange}
              type="text"
              placeholder="What's your name?"
            />
            <button type="submit">Submit</button>
          </form>
        </div>
      )}
    </div>
  );
}

export default App;
