import React, { useState } from "react";
import ReactDOM from "react-dom";
function App() {
  const [count, setCount] = useState(0);
  function increasingOrder() {
    setCount(count + 1);
  }
  function decreasingOrder() {
    setCount(count - 1);
  }
  return (
    <div className="container">
      <h1>{count}</h1>
      <button onClick={increasingOrder}>+</button>
      <button onClick={decreasingOrder}>-</button>
    </div>
  );
}

export default App;
