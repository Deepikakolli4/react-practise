import React from "react";
function Heading() {
  return <h1>MY WORLD!!!</h1>;
}
export default Heading;
