import React from "react";
function Lists() {
  return (
    <ul>
      <li>BREAD</li>
      <li>Fruits</li>
      <li>Milk</li>
    </ul>
  );
}
export default Lists;
