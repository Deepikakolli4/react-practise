import React from "react";
import ReactDOM from "react-dom";
const fname = "Angela";
const lname = "yu";
const number = 10;
ReactDOM.render(
  <div>
    <h1>Hello {fname + " " + lname}!</h1>
    <p> Your lucky number {number}</p>
  </div>,
  document.getElementById("root")
);
