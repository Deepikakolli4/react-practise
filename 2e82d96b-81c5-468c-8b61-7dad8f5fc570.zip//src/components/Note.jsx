import React from "react";
function Note() {
  return (
    <div>
      <h1>Learning React</h1>
      <p>Started FRom Scratch</p>
    </div>
  );
}
export default Note;
