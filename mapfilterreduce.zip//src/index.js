import emojipedia from "./emojipedia";
var numbers = [3, 56, 2, 48, 5];

//Map -Create a new array by doing something with each item in an array.
// const newNumbers = numbers.map(function (number) {
//   return number * 2;
// });

//Filter - Create a new array by keeping the items that return true.
// const newNumbers = numbers.filter(function (number) {
//   return number > 10;
// });
// console.log(newNumbers);
//Reduce - Accumulate a value by doing something to each item in an array.
// const newNumbers = numbers.reduce(function (accumulator, currentNumber) {
//   console.log(accumulator);
//   console.log(currentNumber);
//   return accumulator + currentNumber;
// }, 0);

// console.log(newNumbers);
//Find - find the first item that matches from an array.
// const newNumber = numbers.find(function (number) {
//   return number > 10;
// });
// console.log(newNumber);

//FindIndex - find the index of the first item that matches.
const newNumber = numbers.findIndex(function (number) {
  return number > 10;
});
console.log(newNumber);
const newChallenge = emojipedia.map(function (emojiEntry) {
  return emojiEntry.meaning.substring(1, 100);
});
console.log(newChallenge);
